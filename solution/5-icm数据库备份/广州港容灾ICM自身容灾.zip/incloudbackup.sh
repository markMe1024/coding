#!/bin/sh

mysqlusername=root
mysqlpassword=123456a?

#1-ftp,2-local
backlocation=1
localbackpath=/home/

ftphost=100.2.96.116
ftpusername=oracle
ftppassword=123456a?
ftpbackpath=incloudback

echo 'begin backup----------------- ' 
current=`date "+%Y-%m-%d %H:%M:%S"`
echo $current
s0="/usr/local/"
s1="/home/"
#s2=`date "+%Y%m%d%H%M%S"`
s2="back"
s3=".sql"
s4="influxd"
sqlpath=${s0}${s2}${s3}
influxdname=${s0}${s2}${s4}
influxdpath=${s1}${s2}${s4}
backdir=${s0}${s2}
echo $sqlname
echo $influxdname

rm -rf $backdir
mkdir $backdir

sqlpod=`/usr/local/bin/kubectl get pod -n incloud |grep mysql-0 |awk '{print $1}'`
echo $sqlpod

databases=`/usr/local/bin/kubectl exec $sqlpod -n incloud -- mysql -e "show databases;" -u$mysqlusername -p$mysqlpassword | grep -Ev "information_schema|mysql|test|performance_schema"`

dbs=""
for i in $databases
do
  if [[ $i == i* ]];
  then
    echo $i
    /usr/local/bin/kubectl exec -it $sqlpod -n incloud -- mysqldump -u$mysqlusername -p$mysqlpassword --databases $i --ignore-table=ibase.xxl_job_log -B -R --single-transaction  > ${s0}${s2}"/"$i${s3}
    dbs=$dbs$i" ";
  fi
done
echo $dbs;

#kubectl exec -it $sqlpod -n incloud -- mysqldump -u$mysqlusername -p$mysqlpassword --all-databases --ignore-table=ibase.t_ba_serial_number -B -R --single-transaction  > $sqlpath
#/usr/local/bin/kubectl exec -it $sqlpod -n incloud -- mysqldump -u$mysqlusername -p$mysqlpassword --databases $dbs --ignore-table=ibase.t_ba_serial_number -B -R --single-transaction  > $sqlpath
sleep 3
echo `date`

influxdpod=`/usr/local/bin/kubectl get pod -n incloud |grep influxdb-influxdb |awk '{print $1}'`
echo $influxdpod
/usr/local/bin/kubectl exec $influxdpod -n incloud -- rm -rf $influxdpath
/usr/local/bin/kubectl exec $influxdpod -n incloud -- mkdir $influxdpath

/usr/local/bin/kubectl exec $influxdpod -n incloud -- influxd backup -portable $influxdpath
sleep 3
rm -rf ${influxdname}
/usr/local/bin/kubectl cp $influxdpod:$influxdpath  ${influxdname}  -n incloud

sleep 1

#mv -f $sqlpath $backdir"/"
mv -f $influxdname"/" $backdir"/" 

tarname="back.tar.gz"
tar -zcvf $s0$tarname $backdir


if [[ $backlocation == 2 ]]; 
then
    echo "back up local";
    \cp $s0$tarname $localbackpath
elif [[ $backlocation == 1 ]];
then
    echo "back up ftp";
    ftp -v -n $ftphost << EOF
    user $ftpusername $ftppassword
    binary
    mkdir $ftpbackpath
    cd $ftpbackpath
    lcd $s0
    prompt
    send $tarname
    bye
EOF
fi

echo "end back-------------------"
echo " "


