#!/bin/sh

mysqlusername=root
mysqlpassword=123456a?

#1-ftp,2-local
backlocation=1
localbackpath=/home/

ftphost=100.2.96.116
ftpusername=oracle
ftppassword=123456a?
ftpbackpath=incloudback

echo 'begin restore ------------------------------- ' 
current=`date "+%Y-%m-%d %H:%M:%S"`
echo $current

restoredir='/usr/local/back'
tarname="back.tar.gz"
tarpath=$restoredir"/"$tarname

rm -rf $restoredir
mkdir $restoredir


if [[ $backlocation == 1 ]];
  then
    echo "get back up file from ftp";
    ftp -v -n $ftphost << EOF
    user $ftpusername $ftppassword
    binary
    cd $ftpbackpath
    lcd $restoredir
    prompt
    get $tarname
    bye
EOF
elif [[ $backlocation == 2 ]];
  then
    echo "get back up local";
    \cp -f $localbackpath$tarname $restoredir"/"$tarname
fi



sleep 1 
tar -xzvf $tarpath -C $restoredir"/" --strip-components 3
#mv -f $restoredir$restoredir"/" $restoredir"/"
sleep 2
sqlname=$restoredir"/""back.sql"
sqlpod=`/usr/local/bin/kubectl get pod -n incloud |grep mysql-0 |awk '{print $1}'`
echo $sqlpod

echo "sql restore begin"

database=`ls $restoredir | grep .sql`
echo $database
for i in $database
do
  echo $i
  sqlname=$restoredir"/"$i
  /usr/local/bin/kubectl exec -i $sqlpod -n incloud  -- mysql -u$mysqlusername -p$mysqlpassword < $sqlname
  sleep 1
done

echo "sql restore end"

echo "influxdb restore begin"
influxdpod=`/usr/local/bin/kubectl get pod -n incloud |grep influxdb-influxdb |awk '{print $1}'`
echo $influxdpod

influxdname="backinfluxd"
influxdpath="/home/"$influxdname
/usr/local/bin/kubectl exec $influxdpod -n incloud -- rm -rf $influxdpath
sleep 1
/usr/local/bin/kubectl cp $restoredir"/"${influxdname} $influxdpod:$influxdpath -n incloud
sleep 30

tmpdatabase="inspurtmp"

/usr/local/bin/kubectl exec $influxdpod -n incloud -- influxd restore -portable -db inspur -newdb $tmpdatabase $influxdpath
sleep 1
/usr/local/bin/kubectl exec $influxdpod -n incloud -- influx -execute 'drop database inspur'
sleep 1
/usr/local/bin/kubectl exec $influxdpod -n incloud -- influx -execute 'create database inspur'
echo "insert inspur 1"
sleep 1
/usr/local/bin/kubectl exec $influxdpod -n incloud -- influx -database $tmpdatabase -execute 'select * into inspur..:MEASUREMENT FROM /.*/ GROUP BY *' 
echo "inset end 1"
sleep 30

/usr/local/bin/kubectl exec $influxdpod -n incloud -- influx -execute 'drop database inspurtmp'

echo 'end restore ---------------------'
echo ' '

